<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $problem = $_POST["problem"];
    $filename = "problems/" . preg_replace("/[^a-zA-Z0-9]/", "_", $title) . ".txt";
    file_put_contents($filename, $problem);
    echo "Problem added successfully!<br><a href='admin.php'>Back</a>";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Admin - Create Problem</title></head>
<body>
<h2>Create a New Problem</h2>
<form method="post">
    Title: <input type="text" name="title" required><br><br>
    Problem Description:<br><textarea name="problem" rows="10" cols="50" required></textarea><br><br>
    <input type="submit" value="Add Problem">
</form>
</body>
</html>

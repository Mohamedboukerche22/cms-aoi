import os
from http.server import BaseHTTPRequestHandler, HTTPServer
import cgi, subprocess

class ContestHandler(BaseHTTPRequestHandler):
    def _render(self, content):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(content.encode())

    def do_GET(self):
        if self.path == "/":
            problems = os.listdir("problems")
            html = "<h1>Simple Contest</h1><ul>"
            for p in problems:
                title = p.replace(".txt", "")
                html += f"<li><a href='/problem/{title}'>{title}</a></li>"
            html += "</ul>"
            self._render(html)
        elif self.path.startswith("/problem/"):
            title = self.path.split("/")[-1]
            filepath = f"problems/{title}.txt"
            if os.path.exists(filepath):
                desc = open(filepath).read()
                html = f"<h2>{title}</h2><pre>{desc}</pre>"
                html += f"""
<form method='post' enctype='multipart/form-data'>
    Submit your Python code:<br><textarea name='code' rows='10' cols='60'></textarea><br>
    <input type='hidden' name='title' value='{title}'>
    <input type='submit' value='Submit'>
</form>"""
                self._render(html)
            else:
                self._render("Problem not found.")
        else:
            self._render("Not found.")

    def do_POST(self):
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers,
                                environ={'REQUEST_METHOD': 'POST'})
        code = form.getvalue("code")
        title = form.getvalue("title")
        with open("temp_submission.py", "w") as f:
            f.write(code)
        try:
            result = subprocess.check_output(["python3", "temp_submission.py"], stderr=subprocess.STDOUT, timeout=5)
            output = result.decode()
        except subprocess.CalledProcessError as e:
            output = e.output.decode()
        except Exception as e:
            output = str(e)
        html = f"<h2>Submission Result for {title}</h2><pre>{output}</pre><a href='/'>Back to problems</a>"
        self._render(html)

if __name__ == "__main__":
    os.makedirs("problems", exist_ok=True)
    server = HTTPServer(('0.0.0.0', 8000), ContestHandler)
    print("Server running at http://localhost:8000")
    server.serve_forever()
